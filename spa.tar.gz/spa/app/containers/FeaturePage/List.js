import styled from 'styled-components';

const List = styled.ul`
  font-family: Georgia, Times, 'Times New Roman', serif;
  padding-left: 1.75em;
`;

export default List;
